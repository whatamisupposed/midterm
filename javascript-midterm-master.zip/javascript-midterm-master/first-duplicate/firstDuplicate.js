function firstDuplicate(array) {
  
}
