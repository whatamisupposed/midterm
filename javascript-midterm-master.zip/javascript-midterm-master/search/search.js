function search(nameList, searchTerm) {

}